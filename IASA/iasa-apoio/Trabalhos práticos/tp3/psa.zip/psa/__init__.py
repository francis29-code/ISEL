from psa5 import iniciar, executar, reiniciar, terminar, info, \
                 pausa, vis, actvis, espera, dirmov, custoaccao
