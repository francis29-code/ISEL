class Controlo:

    def processar(self,Percepcao):
        abstract
        #retorna uma accao
        # raise NotImplementedError
