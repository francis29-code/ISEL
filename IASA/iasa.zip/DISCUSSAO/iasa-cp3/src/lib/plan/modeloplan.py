

class ModeloPlan:

    def estados(self):
        #retorna lista de estados
        raise NotImplementedError

    def operadores(self):
        #retorna lista operadores
        raise NotImplementedError
