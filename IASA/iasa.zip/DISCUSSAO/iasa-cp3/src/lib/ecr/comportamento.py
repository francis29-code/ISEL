class Comportamento:

    def activar(self,percepcao):
        #retorna uma resposta
        raise NotImplementedError
