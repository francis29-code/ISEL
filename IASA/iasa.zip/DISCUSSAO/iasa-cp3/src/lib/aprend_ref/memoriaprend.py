
class MemoriAprend:

    def actualizar(self,s,a,q):
        raise NotImplementedError

    def obter(self,s,a):
        raise NotImplementedError
