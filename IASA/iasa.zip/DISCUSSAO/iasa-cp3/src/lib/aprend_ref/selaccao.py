
class SelAccao:

    def selecionar_accao(self,s):
        raise NotImplementedError
