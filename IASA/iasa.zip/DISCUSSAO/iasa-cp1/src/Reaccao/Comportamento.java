package Reaccao;

public abstract interface Comportamento {
	public abstract Accao ativar(Estimulo estimulo);
}
