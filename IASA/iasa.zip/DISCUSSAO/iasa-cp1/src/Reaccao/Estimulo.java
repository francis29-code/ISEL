package Reaccao;

public abstract interface Estimulo {

}
