package Reaccao;

public abstract interface Accao {
	public abstract void executar();
}
