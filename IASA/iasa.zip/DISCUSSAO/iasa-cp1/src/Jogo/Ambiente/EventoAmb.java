package Jogo.Ambiente;

import Reaccao.Estimulo;

public enum EventoAmb implements Estimulo{
	SILENCIO,RUIDO,INIMIGO,FUGA,VITORIA,DERROTA,TERMINAR
}
